
//Get Date 
var today = new Date();
var last_few_child;
var last_few_time=new Array();
var last_few_temperature=[];
var last_few_humidity=[];
var temp=[1,2,3];
console.log(typeof last_few_temperature)
//Add Trailing Zeros
function convert_to_0x(m){
    if (m < 10) {m = "0"+m;}return m}

var date = today.getFullYear()+'-'+convert_to_0x((today.getMonth()+1))+'-'+convert_to_0x(today.getDate());

var firebase_object=firebase.database().ref(date+"/lora_feather")
// firebase_object.on("value", function(snapshot) {
//     console.log(snapshot.val());
//  }, function (error) {
//     console.log("Error: " + error.code);
//  });
firebase_object.orderByKey().limitToLast(10).on('value',function(snapshot){
    last_few_child= snapshot.val();
    console.log(last_few_child);
    // last_few_time=Object.keys(last_few_child);
    // console.log(last_few_time);
    for ( var time in last_few_child){
        console.log(time,(last_few_child[time]).temperature,(last_few_child[time]).humidity);
        last_few_time.push(time);
        last_few_temperature.push((last_few_child[time]).temperature);
        last_few_humidity.push((last_few_child[time]).humidity);
    }
  });

  console.log(last_few_time);
  console.log(last_few_temperature);
  console.log(last_few_humidity);


var trace1 = {
    x: last_few_time,
    y:last_few_temperature,
    type: 'spline',
    name:'Temperature'
};
var trace2 = {
    x: last_few_time,
    y: last_few_humidity,
    type: 'spline',
    name:'Humidity'
};
var data = [trace1, trace2];

var layout1 = {
    animate:true,
    xaxis:{title:'Timestamp',
                titlefont:{
                family:'Courier New, monospace',
                size:18,
                color:'#7f7f7f'
                }

            },
    yaxis: {
        title:'Temperature,Humidity',
        titlefont:{
            family:'Courier New, monospace',
            size:18,
            color:'#7f7f7f'
            },
        showline: true,
        zeroline: true,
        range:[0,100]

        
    },
    title:'Last Updated'
};

setInterval(function() {

Plotly.newPlot('chart_1', data, layout1);
}, 500);
//Plotly.plot('div2', data, layout2);